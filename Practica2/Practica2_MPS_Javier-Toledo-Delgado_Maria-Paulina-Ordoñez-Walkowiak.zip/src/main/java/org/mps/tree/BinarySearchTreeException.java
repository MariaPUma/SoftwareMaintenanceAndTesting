package org.mps.tree;

public class BinarySearchTreeException extends RuntimeException {
    public BinarySearchTreeException(String message) {
        super(message);
    }
}
